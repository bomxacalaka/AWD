
    <title>My Home Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
        }

        p {
            color: #666;
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to My Home Page</h1>
        <p>This is a sample home page created using PHP.</p>
    </div>
</body>

<!-- 
sudo apt-get update -y
sudo apt-get upgrade -y

sudo apt-get purge mysql-server mysql-client -y
sudo apt-get autoremove -y
sudo apt-get autoclean -y
sudo apt-get install mysql-server mysql-client -y

sudo rm /etc/mysql -R

sudo find / -name 'my.cnf' 
-->