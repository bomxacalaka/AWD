
<h1 class="mb-4">Models</h1>
<hr>
<div class="container mt-5">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Model Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Model 1</td>
                    <td>Description of Model 1</td>
                    <td>
                        <button type="button" class="btn btn-primary">Edit</button>
                        <button type="button" class="btn btn-danger">Delete</button>
                    </td>
                </tr>
                <tr>
                    <td>Model 2</td>
                    <td>Description of Model 2</td>
                    <td>
                        <button type="button" class="btn btn-primary">Edit</button>
                        <button type="button" class="btn btn-danger">Delete</button>
                    </td>
                </tr>
                <!-- Add more rows for additional models -->
            </tbody>
        </table>
    </div>