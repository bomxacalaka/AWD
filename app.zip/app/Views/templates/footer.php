<!-- Add some space above the footer -->
</div>
</div>
</body>
<div style="height: 50px;"></div>

<head>
  <style>
    body {
      background-color: #212529;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      margin: 0;
      overflow-x: hidden;
    }

    .container-fluid {
      margin: 0;
      /* Add this line to remove default margin */
      padding: 0;
      /* Add this line to remove default padding */
    }

    footer {
      background-color: #333;
      color: #fff;
      text-align: center;
      padding: 0px 0;
      margin-top: auto;
      /* Push footer to the bottom of the page */
    }
  </style>
</head>
<!-- Footer -->
<footer class="bg-dark text-center text-white">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="p-3" style="background-color: rgba(0, 0, 0, 0.2);">
          <!-- Section: Social media -->
          <section class="mb-2">
            <!-- Social media icons -->
            <a class="btn btn-outline-light btn-floating m-1" href="https://www.linkedin.com/in/jorge-dal/" role="button"><i
                class="fab fa-linkedin-in"></i></a>
            <a class="btn btn-outline-light btn-floating m-1" href="https://github.com/bomxacalaka" role="button"><i class="fab fa-github"></i></a>
          </section>
        </div>
      </div>
      <div class="text-center p-3" style="background-color: #000000;">
        <!-- Copyright information -->
        © 2024 Copyright:
        <a class="text-white" href="https://h.drbom.net">h.drbom.net</a>
      </div>
    </div>
  </div>
</footer>
<!-- End of Footer -->

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>